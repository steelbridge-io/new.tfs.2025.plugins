
/* JS for the holiday template color picker */
jQuery(document).ready(function($){
    $('.meta-color').wpColorPicker();
    $('.meta-color-text').wpColorPicker();
    $('.meta-grid-bg-color').wpColorPicker();
    $('.meta-content-bg-color').wpColorPicker();
    $('.meta-content-text-color').wpColorPicker();
});
	
