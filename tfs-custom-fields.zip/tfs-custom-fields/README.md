# TFS Custom Fields
GitHub repo: https://github.com/steelbridge-io/tfs-plugins/tree/master/tfs-custom-fields

This plugin works with the-fly-shop theme found here
GitHub repo: https://github.com/steelbridge-io/the-fly-shop

TFS Custom Fields provides all the custom meta fileds for all templates and CPT's.

Should be used with the following plugin, sbm-image-field:
GitHub repo: https://github.com/steelbridge-io/tfs-plugins/tree/master/sbm-image-field