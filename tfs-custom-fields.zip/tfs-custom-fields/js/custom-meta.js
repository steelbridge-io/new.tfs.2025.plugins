/* JS for color picker */
jQuery(document).ready(function($){
    $('.cust-meta-survey-bg-color').wpColorPicker();
    $('.survey-cont-border-color').wpColorPicker();
    $('.survey-cont-bg-color').wpColorPicker();
    $('.survey-author-bg-color').wpColorPicker();
    $('.cust-meta-survey-heading-color').wpColorPicker();
    $('.survey-author-heading-color').wpColorPicker();
    $('.survey-author-desc-color').wpColorPicker();
    $('.basicblog-template-bg-color').wpColorPicker();
    $('.basic-blog-text-color-button').wpColorPicker();
    $('.basicblog-fullpage-bg-color').wpColorPicker();
    $('.basicblog-fullpage-txt-color').wpColorPicker();
    $('.basicblog-sidebar-bg-color').wpColorPicker();
});




